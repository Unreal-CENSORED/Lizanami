package name.lizanami_mod.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftServer.class)
public class ExampleMixin {
	@Inject(at = @At("HEAD"), method = "getProjectileDamage")
	private void onGetProjectileDamage(DamageSource damageSource, Entity entity, CallbackInfoReturnable<ActionResult> ci) {
		if (entity instanceof LivingEntity && damageSource.getAttacker() instanceof LivingEntity) {
			LivingEntity attacker = (LivingEntity) damageSource.getAttacker();
			LivingEntity target = (LivingEntity) entity;

			// Swap positions
			double attackerX = attacker.getX();
			double attackerY = attacker.getY();
			double attackerZ = attacker.getZ();

			attacker.teleport(target.getX(), target.getY(), target.getZ());
			target.teleport(attackerX, attackerY, attackerZ);

			// Create bats
			for (int i = 0; i < 3; i++) {
				// Adjust the position for each bat if needed
				double offsetX = attacker.getRandom().nextGaussian() * 0.02;
				double offsetY = attacker.getRandom().nextGaussian() * 0.02;
				double offsetZ = attacker.getRandom().nextGaussian() * 0.02;
				attacker.world.spawnEntity(new BatEntity(attacker.world, attacker.getX() + offsetX, attacker.getY() + offsetY, attacker.getZ() + offsetZ));
			}

			// Apply damage to attacker
			float damage = target.getHealth() - 1.0F;
			if (damage < 0.0F) {
				damage = 0.0F;
			}
			attacker.damage(DamageSource.GENERIC, damage);

			// Make target immune to damage
			target.setInvulnerable(true);
		}
	}
}
